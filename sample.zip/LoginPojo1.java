	package org.pojo1;

	import org.base.BaseClass;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;

		public class LoginPojo1 extends BaseClass {
			public LoginPojo1() {
				PageFactory.initElements(driver, this);
			}

			@FindBy(xpath = "//i[@class='wewidgeticon we_close']")
			private WebElement adremove;
			
			@FindBy(xpath = "//a[text()='Search']")
			private WebElement search;
			
			@FindBy(xpath = "//span[@class='bgProperties icon20 overlayCrossIcon']")
			private WebElement close;
			
			@FindBy(xpath = "(//button[text()='VIEW ALL'])[1]")
			private WebElement viewall;
			
			@FindBy(xpath = "(//span[text()='View Prices'])[1]")
			private WebElement viewprices;
			
			@FindBy(xpath = "//button[text()='Book Now']")
			private WebElement book;
			@FindBy(xpath = "//div[@class='listingCardWrap ']")
			private WebElement print;

			public WebElement getclose() {
			return close;
			}
			public WebElement getadremove() {
				return adremove;
			}
			public WebElement getSearch() {
				return search;
			}
		
			
			public WebElement getviewall() {
				return viewall;
			}
			public WebElement getviewprices() {
				return viewprices;
			}
			public WebElement getbook() {
				return book;
			}
			public WebElement print() {
				return print;
			}
		}




	


