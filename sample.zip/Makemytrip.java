package org.sample;

import org.base.BaseClass;
import org.pojo1.LoginPojo1;


public class Makemytrip extends BaseClass{
	public static void main(String[] args) throws InterruptedException {
		launchBrowser();
		Thread.sleep(2000);
		loadUrl("https://www.makemytrip.com/");
		maxBrowser();
		pageTitle();
		LoginPojo1 p = new LoginPojo1();
		//Thread.sleep(3000);
		//btnClick(p.getadremove());
		btnClick(p.getSearch());
		toGetText(p.print());
		btnClick(p.getviewall());
		btnClick(p.getviewprices());
		btnClick(p.getbook());
		System.out.println("Done");

	}
}
